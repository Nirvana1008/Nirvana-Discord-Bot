const Discord = require("discord.js");

exports.run = async (client, message, args) => {
  if (!message.member.hasPermission("MANAGE_NICKNAMES"))
    return message.channel.send(
      `:x: Bu Komutu Kullanabilmek için \`İsimleri Yönet\` Yetkisine Sahip Olmalısın!`
    );
  let member = message.mentions.members.first();
if(!member) return message.channel.send(
new Discord.RichEmbed()
.setColor('BLACK')//İstediğiniz Rengin İngilizcesi'ni '' yazan yere yazabilirsiniz!
.setTitle('HATA')
.setDescription('Rol Verilecek Kişiyi Etiketlemelisin!'))  
  member.removeRole('kayıtsızid')//kayıtsız rol id
  member.addRole('kızid')//kadın rolü id
const embed = new Discord.RichEmbed()


      .addField(`**${member.user} Sunucumuza Kayıt Oldu! Hep Beraber Hoşgeldin Diyelim :blush:!**`,
      `\n**Aramıza Katılan Kullanıcı:** ${member.user} \n\n**Aramıza Tekrardan Hoşgeldin Ses Odasında Sohbet Edecek Birilerini Bulmaya Ne Dersin?**`)
client.channels.get('Bu Mesajın Atılacağı Kanal idsi').send(embed)//genel sohbetin id'sini girerseniz daha iyi olur



 return message.channel.send(
 new Discord.RichEmbed()
    .setColor('BLACK')//İstediğiniz Rengin İngilizcesi'ni '' yazan yere yazabilirsiniz!
    .setAuthor('')//botun ismini yada başka birşeyini yazabilirsiniz yada sunucu ismini falan herşeyi yazabilirsiniz
    .setTitle('Kadın rolü verildi')
    .setDescription(`Kadın Rolü Verilen ${member.user} Kadın Rolü Olarak <@&Kadın rolünün id> Verildi`)
    .setFooter('')//en alttaki açıklama kısmı burası
)}
exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ["k"],
  permLevel: 0
};
exports.help = {
  name: "kadın",
  description: "",
  usage: ""
};