const Discord = require("discord.js");

exports.run = async (client, message, args) => {
  if (!message.member.hasPermission("MANAGE_NICKNAMES"))
    return message.channel.send(
      `:x: Bu Komutu Kullanabilmek için \`İsimleri Yönet\` Yetkisine Sahip Olmalısın!`
    );
  let member = message.mentions.members.first();
if(!member) return message.channel.send(
new Discord.RichEmbed()
.setColor('RED')//İstediğiniz Rengin İngilizcesi'ni '' yazan yere yazabilirsiniz!
.setTitle('HATA')
.setDescription('Kayıt Etmek İstediğin Kişiyi Etiketlemelisin!'))  
  member.removeRole('kayıtsızid')//kayıtssız rol id
  member.addRole('erkekid')//erkek rolü id
const embed = new Discord.RichEmbed()


      .addField(`**${member.user} Sunucumuza Kayıt Oldu! Hep Beraber Hoşgeldin Diyelim :blush:**`,
      `\n**Aramıza Katılan Kullanıcı:** ${member.user} \n\n**Aramıza Tekrardan Hoşgeldin Ses Odasında Sohbet Edecek Birilerini Bulmaya Ne Dersin?**`)
client.channels.get('kanalid').send(embed)//genel sohbetin id'sini girerseniz daha iyi olur



 return message.channel.send(
 new Discord.RichEmbed()
    .setColor('BLACK')//İstediğiniz Rengin İngilizcesi'ni '' yazan yere yazabilirsiniz!
    .setAuthor('Nirvana')//botun ismini yada başka birşeyini yazabilirsiniz yada sunucu ismini falan herşeyi yazabilirsiniz
    .setTitle('Erkek Üye Olarak Başarı İle Kayıt Edildi!')
    .setDescription(`Erkek Rolü Verilen ${member.user} Erkek Üye Olarak Başarı İle Kaydedildi Hoşgeldin!`)
    .setFooter('Studi Developer Team')//en alttaki açıklama kısmı
)}
exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ["e"],
  permLevel: 0
};
exports.help = {
  name: "erkek",
  description: "",
  usage: ""
};